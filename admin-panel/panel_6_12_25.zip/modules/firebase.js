// --------------------------------------------------------------------
// MÓDULO: FIREBASE
// --------------------------------------------------------------------
// Descripción: Este módulo se encarga exclusivamente de la 
// inicialización de Firebase. Centraliza la configuración y exporta
// las instancias del SDK (db, auth) para que otros módulos 
// puedan importarlas y utilizarlas, asegurando que solo se 
// inicialice una vez.
// --------------------------------------------------------------------

// Se importa desde el script global cargado en el HTML
const firebase = window.firebase;

// Tu configuración de Firebase
const firebaseConfig = {
  apiKey: "AIzaSyAvBw_Cc-t8lfip_FtQ1w_w3DrPDYpxINs",
  authDomain: "sistema-fidelizacion.firebaseapp.com",
  projectId: "sistema-fidelizacion",
  storageBucket: "sistema-fidelizacion.appspot.com",
  messagingSenderId: "357176214962",
  appId: "1:357176214962:web:6c1df9b74ff0f3779490ab"
};

// Inicializar la aplicación de Firebase
const app = firebase.initializeApp(firebaseConfig);

// Obtener las instancias de los servicios que vamos a utilizar
const db = firebase.firestore();
const auth = firebase.auth();

// Exportar las instancias para que estén disponibles en otros módulos
export { db, auth, firebase };